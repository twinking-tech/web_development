// Function to toggle the menu visibility
function toggleMenu() {
    var menu = document.getElementById('menu');
    menu.classList.toggle('open');
}

// Close the menu if clicked outside
document.addEventListener('click', function(event) {
    var menu = document.getElementById('menu');
    var hamburger = document.querySelector('.hamburger');

    // If the click is outside the menu and hamburger icon, close the menu
    if (!menu.contains(event.target) && !hamburger.contains(event.target)) {
        menu.classList.remove('open');
    }
});
